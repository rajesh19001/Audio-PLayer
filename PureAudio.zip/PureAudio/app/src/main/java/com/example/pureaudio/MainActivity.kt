package com.example.pureaudio

import android.Manifest
import android.content.ContentUris
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

// Data model for our songs
data class AudioTrack(val id: Long, val title: String, val artist: String, val uri: android.net.Uri)

class MainActivity : ComponentActivity() {

    private var player: ExoPlayer? = null
    private val audioList = mutableStateOf<List<AudioTrack>>(emptyList())
    private val hasPermission = mutableStateOf(false)

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasPermission.value = isGranted
        if (isGranted) loadAudioFiles()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initPlayer()

        // Handle Permissions based on Android Version
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionLauncher.launch(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        setContent {
            if (hasPermission.value) MinimalistPlayerUI(player, audioList.value)
            else LoadingScreen()
        }
    }

    private fun initPlayer() {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    private fun loadAudioFiles() {
        lifecycleScope.launch(Dispatchers.IO) {
            val list = mutableListOf<AudioTrack>()
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

            val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

            contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    list.add(AudioTrack(id, cursor.getString(titleCol), cursor.getString(artistCol) ?: "<unknown>", contentUri))
                }
            }
            withContext(Dispatchers.Main) { audioList.value = list }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
    }
}

// Format time for the slider
fun formatDuration(durationMs: Long): String {
    if (durationMs < 0) return "00:00"
    val minutes = (durationMs / 1000) / 60
    val seconds = (durationMs / 1000) % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}

@Composable
fun LoadingScreen() {
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF121212)) {
        Box(contentAlignment = Alignment.Center) { Text("Scanning storage...", color = Color.Gray) }
    }
}

@Composable
fun MinimalistPlayerUI(player: ExoPlayer?, songList: List<AudioTrack>) {
    var isPlaying by remember { mutableStateOf(false) }
    var isShuffle by remember { mutableStateOf(false) }
    var currentSongTitle by remember { mutableStateOf("Select a song") }
    var audioQualityInfo by remember { mutableStateOf("") }
    var sleepTimerMinutes by remember { mutableIntStateOf(0) }

    var showMenu by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showAppearanceDialog by remember { mutableStateOf(false) }
    var accentColor by remember { mutableStateOf(Color(0xFF00FF00)) }

    var artworkBytes by remember { mutableStateOf<ByteArray?>(null) }
    var artworkBitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    // Background Image Processing
    LaunchedEffect(artworkBytes) {
        artworkBitmap = if (artworkBytes != null) {
            withContext(Dispatchers.IO) {
                BitmapFactory.decodeByteArray(artworkBytes, 0, artworkBytes!!.size)?.asImageBitmap()
            }
        } else null
    }

    // Load playlist into engine
    LaunchedEffect(songList) {
        if (songList.isNotEmpty() && player?.mediaItemCount == 0) {
            val items = songList.map { MediaItem.fromUri(it.uri) }
            player.setMediaItems(items)
            player.prepare()
        }
    }

    // Player State Listeners
    DisposableEffect(player, songList) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val index = player?.currentMediaItemIndex ?: -1
                if (index in songList.indices) currentSongTitle = songList[index].title
            }
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaMetadataChanged(metadata: MediaMetadata) { artworkBytes = metadata.artworkData }

            @OptIn(UnstableApi::class)
            override fun onTracksChanged(tracks: Tracks) {
                for (group in tracks.groups) {
                    if (group.isSelected && group.type == C.TRACK_TYPE_AUDIO) {
                        val format = group.getTrackFormat(0)
                        val rawMime = format.sampleMimeType?.substringAfterLast("/")?.uppercase() ?: "AUDIO"
                        val displayFormat = when(rawMime) {
                            "MPEG" -> "MP3"; "MP4A-LATM" -> "AAC"; "X-WAV" -> "WAV"; "FLAC" -> "FLAC"; else -> rawMime
                        }
                        val sampleRate = if (format.sampleRate > 0) "${format.sampleRate / 1000.0} kHz" else ""
                        val bitVal = if (format.bitrate > 0) format.bitrate else if (format.peakBitrate > 0) format.peakBitrate else 0
                        val bitrate = if (bitVal > 0) "${bitVal / 1000} kbps" else ""

                        val details = listOf(displayFormat, sampleRate, bitrate).filter { it.isNotBlank() }
                        audioQualityInfo = details.joinToString("  •  ")
                    }
                }
            }
        }
        player?.addListener(listener)
        onDispose { player?.removeListener(listener) }
    }

    // Sleep Timer Loop
    LaunchedEffect(sleepTimerMinutes) {
        if (sleepTimerMinutes > 0) {
            delay(sleepTimerMinutes * 60 * 1000L)
            player?.pause()
            sleepTimerMinutes = 0
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF121212)) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // Header
            Row(modifier = Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("PureAudio", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Lossless Ready", color = accentColor, style = MaterialTheme.typography.bodyMedium)
                }
                Box {
                    IconButton(onClick = { showMenu = true }) { Icon(Icons.Default.MoreVert, "Menu", tint = Color.White) }
                    DropdownMenu(showMenu, { showMenu = false }, containerColor = Color(0xFF222222)) {
                        DropdownMenuItem(text = { Text("Appearance", color = Color.White) }, onClick = { showAppearanceDialog = true; showMenu = false })
                        DropdownMenuItem(text = { Text("About", color = Color.White) }, onClick = { showAboutDialog = true; showMenu = false })
                    }
                }
            }
            Spacer(Modifier.height(24.dp))

            // Artwork
            Box(Modifier.size(220.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF222222)), Alignment.Center) {
                if (artworkBitmap != null) Image(artworkBitmap!!, "Art", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Default.MusicNote, null, Modifier.size(80.dp), Color.Gray)
            }
            Spacer(Modifier.height(24.dp))

            // List (Optimized with Keys)
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                itemsIndexed(items = songList, key = { _, track -> track.id }) { index, track ->
                    SongListItem(track, track.title == currentSongTitle, accentColor) {
                        currentSongTitle = track.title
                        player?.seekTo(index, 0L)
                        player?.play()
                    }
                }
            }

            // Playback Info
            Spacer(Modifier.height(16.dp))
            Text(currentSongTitle, color = accentColor, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
            if (audioQualityInfo.isNotEmpty()) {
                Text(audioQualityInfo, color = Color(0xFFFFD700), fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }

            TrackTimeline(player, isPlaying, accentColor)
            Spacer(Modifier.height(16.dp))

            // Controls
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { sleepTimerMinutes = when(sleepTimerMinutes){ 0->15; 15->30; 30->60; else->0 } }) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Timer, null, tint = if(sleepTimerMinutes>0) accentColor else Color.Gray)
                        if(sleepTimerMinutes>0) Text("${sleepTimerMinutes}m", color = accentColor, fontSize = 10.sp)
                    }
                }
                IconButton(onClick = { player?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(32.dp)) }
                FloatingActionButton(onClick = { if(isPlaying) player?.pause() else player?.play() }, containerColor = Color.White) {
                    Icon(if(isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(36.dp))
                }
                IconButton(onClick = { player?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(32.dp)) }
                IconButton(onClick = { isShuffle = !isShuffle; player?.shuffleModeEnabled = isShuffle }) {
                    Icon(Icons.Default.Shuffle, null, tint = if(isShuffle) accentColor else Color.Gray)
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        // Dialogs
        if (showAboutDialog) {
            AlertDialog(onDismissRequest = { showAboutDialog = false }, containerColor = Color(0xFF222222),
                title = { Text("About", color = Color.White) },
                text = { Text("Developed by Rajesh for Audiophiles.", color = Color.LightGray) },
                confirmButton = { TextButton(onClick = { showAboutDialog = false }) { Text("Close", color = accentColor) } })
        }
        if (showAppearanceDialog) {
            AlertDialog(onDismissRequest = { showAppearanceDialog = false }, containerColor = Color(0xFF222222),
                title = { Text("Accent Color", color = Color.White) },
                text = {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                        listOf(Color(0xFF00FF00), Color(0xFF00BFFF), Color(0xFFFF3366)).forEach { color ->
                            Box(Modifier.size(40.dp).clip(CircleShape).background(color).clickable { accentColor = color; showAppearanceDialog = false })
                        }
                    }
                }, confirmButton = { TextButton(onClick = { showAppearanceDialog = false }) { Text("Cancel", color = Color.Gray) } })
        }
    }
}

@Composable
fun SongListItem(track: AudioTrack, isCurrent: Boolean, accent: Color, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp)) {
        Text(track.title, color = if(isCurrent) accent else Color.White, fontSize = 16.sp, maxLines = 1)
        Text(track.artist, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
        HorizontalDivider(Modifier.padding(top = 12.dp), color = Color(0xFF222222))
    }
}

@Composable
fun TrackTimeline(player: ExoPlayer?, isPlaying: Boolean, accent: Color) {
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }

    LaunchedEffect(isPlaying, dragging) {
        while (isActive && isPlaying && !dragging) {
            pos = player?.currentPosition ?: 0L
            dur = player?.duration?.coerceAtLeast(0L) ?: 0L
            delay(500L)
        }
    }

    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(formatDuration(pos), color = Color.Gray, fontSize = 12.sp)
        Slider(
            value = if (dur > 0) pos.toFloat() / dur.toFloat() else 0f,
            onValueChange = { dragging = true; pos = (it * dur).toLong() },
            onValueChangeFinished = { dragging = false; player?.seekTo(pos) },
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
        )
        Text(formatDuration(dur), color = Color.Gray, fontSize = 12.sp)
    }
}